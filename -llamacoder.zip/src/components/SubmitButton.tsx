import React from 'react'
import { Loader2 } from 'lucide-react'

interface SubmitButtonProps {
  isLoading: boolean
  disabled: boolean
}

export default function SubmitButton({ isLoading, disabled }: SubmitButtonProps) {
  return (
    <button
      type="submit"
      disabled={disabled}
      className={`
        w-full flex items-center justify-center px-4 py-2 
        text-sm font-medium text-white rounded-md
        bg-blue-600 hover:bg-blue-700
        focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
        disabled:opacity-50 disabled:cursor-not-allowed
        transition-all duration-200
        transform hover:scale-[1.02] active:scale-[0.98]
        ${disabled ? 'hover:bg-blue-600 transform-none' : ''}
      `}
      aria-label={isLoading ? 'Signing in' : 'Sign in'}
    >
      {isLoading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" aria-hidden="true" />
          Signing in...
        </>
      ) : (
        'Sign In'
      )}
    </button>
  )
}