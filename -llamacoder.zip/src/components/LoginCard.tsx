import React from 'react'
import { Card, CardContent, CardHeader } from '../components/ui/card'
import FormInput from './FormInput'
import SubmitButton from './SubmitButton'

interface LoginCardProps {
  email: string
  password: string
  rememberMe: boolean
  isLoading: boolean
  errors: {
    email?: string
    password?: string
    general?: string
  }
  isSuccess: boolean
  onEmailChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onRememberMeChange: (checked: boolean) => void
  onSubmit: (e: React.FormEvent) => void
}

export default function LoginCard({
  email,
  password,
  rememberMe,
  isLoading,
  errors,
  isSuccess,
  onEmailChange,
  onPasswordChange,
  onRememberMeChange,
  onSubmit,
}: LoginCardProps) {
  return (
    <Card className="w-full max-w-md bg-white shadow-lg">
      <CardHeader className="space-y-1 px-8 pt-8 pb-4">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Sign In</h1>
          <p className="text-sm text-gray-600 mt-2">
            Enter your credentials to access your account
          </p>
        </div>
      </CardHeader>
      
      <CardContent className="px-8 pb-8">
        {isSuccess && (
          <div 
            className="mb-4 p-3 bg-green-50 border border-green-200 rounded-md text-green-800 text-sm"
            role="alert"
            aria-live="polite"
          >
            Login successful! Redirecting...
          </div>
        )}
        
        {errors.general && (
          <div 
            className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md text-red-800 text-sm"
            role="alert"
            aria-live="polite"
          >
            {errors.general}
          </div>
        )}
        
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <FormInput
            id="email"
            label="Email address"
            type="email"
            value={email}
            onChange={onEmailChange}
            error={errors.email}
            autoComplete="email"
            required
            disabled={isLoading}
          />
          
          <FormInput
            id="password"
            label="Password"
            type="password"
            value={password}
            onChange={onPasswordChange}
            error={errors.password}
            autoComplete="current-password"
            required
            disabled={isLoading}
          />
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <input
                id="remember-me"
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => onRememberMeChange(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                disabled={isLoading}
              />
              <label 
                htmlFor="remember-me" 
                className="text-sm text-gray-700 cursor-pointer select-none"
              >
                Remember me
              </label>
            </div>
            
            <button
              type="button"
              className="text-sm text-blue-600 hover:text-blue-500 font-medium disabled:opacity-50"
              disabled={isLoading}
              onClick={() => {/* Handle forgot password */}}
            >
              Forgot password?
            </button>
          </div>
          
          <SubmitButton
            isLoading={isLoading}
            disabled={!email || !password || isLoading}
          />
        </form>
      </CardContent>
    </Card>
  )
}