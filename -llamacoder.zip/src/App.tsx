import React, { useState } from 'react'
import LoginCard from './components/LoginCard'

interface FormErrors {
  email?: string
  password?: string
  general?: string
}

export default function App() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<FormErrors>({})
  const [isSuccess, setIsSuccess] = useState(false)

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}

    if (!email) {
      newErrors.email = 'Email is required'
    } else if (!validateEmail(email)) {
      newErrors.email = 'Please enter a valid email address'
    }

    if (!password) {
      newErrors.password = 'Password is required'
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }

    setIsLoading(true)
    setErrors({})

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      
      // Mock success/failure (50/50 chance for demo)
      if (Math.random() > 0.5) {
        setIsSuccess(true)
        // Reset form after success
        setTimeout(() => {
          setEmail('')
          setPassword('')
          setRememberMe(false)
          setIsSuccess(false)
        }, 2000)
      } else {
        setErrors({ general: 'Invalid email or password' })
      }
    }, 1500)
  }

  const handleInputChange = (field: 'email' | 'password', value: string) => {
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }))
    }
    if (errors.general) {
      setErrors(prev => ({ ...prev, general: undefined }))
    }

    if (field === 'email') {
      setEmail(value)
    } else {
      setPassword(value)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
      <LoginCard
        email={email}
        password={password}
        rememberMe={rememberMe}
        isLoading={isLoading}
        errors={errors}
        isSuccess={isSuccess}
        onEmailChange={(value) => handleInputChange('email', value)}
        onPasswordChange={(value) => handleInputChange('password', value)}
        onRememberMeChange={setRememberMe}
        onSubmit={handleSubmit}
      />
    </div>
  )
}